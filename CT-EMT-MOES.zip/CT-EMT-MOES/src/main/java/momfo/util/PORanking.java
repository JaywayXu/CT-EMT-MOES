//  Ranking.java
//
//  Author:
//       Antonio J. Nebro <antonio@lcc.uma.es>
//       Juan J. Durillo <durillo@lcc.uma.es>
//
//  Copyright (c) 2011 Antonio J. Nebro, Juan J. Durillo
//
//  This program is free software: you can redistribute it and/or modify
//  it under the terms of the GNU Lesser General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU Lesser General Public License for more details.
// 
//  You should have received a copy of the GNU Lesser General Public License
//  along with this program.  If not, see <http://www.gnu.org/licenses/>.

package momfo.util;

import momfo.core.Solution;
import momfo.core.SolutionSet;
import momfo.util.comparators.OverallConstraintViolationComparator;
import momfo.util.comparators.PODominanceComparator;

import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/**
 * This class implements some facilities for ranking solutions. Given a
 * <code>SolutionSet</code> object, their solutions are ranked according to
 * scheme proposed in NSGA-II; as a result, a set of subsets are obtained. The
 * subsets are numbered starting from 0 (in NSGA-II, the numbering starts from
 * 1); thus, subset 0 contains the non-dominated solutions, subset 1 contains
 * the non-dominated solutions after removing those belonging to subset 0, and
 * so on.
 * 该类实现了对解决方案进行排序的一些工具。给定一个* <code>SolutionSet</code> 对象，
 * 解决方案按照* NSGA-II建议的方案;结果得到一组子集。
 * 子集的编号从0开始(在NSGA-II中，编号从1开始*)
 * 因此，子集0包含非支配解，子集1包含*去掉属于子集0的非优势解，以下依次列举等等。
 */
public class PORanking {

    /**
     * The <code>SolutionSet</code> to rank
     */
    private SolutionSet solutionSet_;

    /**
     * An array containing all the fronts found during the search
     * 包含搜索过程中发现的所有前沿的数组
     */
    private SolutionSet[] ranking_;

    /**
     * stores a <code>Comparator</code> for dominance checking
     * 存储一个Comparator用于优势的检查
     */
    private static Comparator dominance_;

    /**
     * stores a <code>Comparator</code> for Overal Constraint Violation
     * Comparator checking
     * 存储一个<code>Comparator</code>，用于检查总体约束违反
     */
    private static Comparator constraint_ = new OverallConstraintViolationComparator();

    public PORanking(SolutionSet solutionSet, boolean[] isChosen) {
        solutionSet_ = solutionSet;
        // 将isChosen 赋值给PODominanceComparator类变量 	boolean[] isChosen_
        dominance_ = new PODominanceComparator(isChosen);

        // dominateMe[i] contains the number of solutions dominating i
        int[] dominateMe = new int[solutionSet_.size()];

        // iDominate[k] contains the list of solutions dominated by k
        //列表类型的数组
        List<Integer>[] iDominate = new List[solutionSet_.size()];

        // front[i] contains the list of individuals belonging to the front i
        List<Integer>[] front = new List[solutionSet_.size() + 1];

        // flagDominate is an auxiliar encodings.variable
        int flagDominate;

        // Initialize the fronts
        //front是一个数组，其中的每个元素都是一个列表，例如front[0]表示第0层非支配前沿，
        // 但是现在每一个前沿中有多少个体有多少个前沿都是未知的
        //但是初始化时，front.length会根据new List[solutionSet_.size() + 1]进行初始化
        for (int i = 0; i < front.length; i++)
            front[i] = new LinkedList<Integer>();

        /*
         * //-> Fast non dominated sorting algorithm for (int p = 0; p <
         * solutionSet_.size(); p++) { // Initialice the list of individuals
         * that i dominate and the number // of individuals that dominate me
         * iDominate[p] = new LinkedList<Integer>(); dominateMe[p] = 0; // For
         * all q individuals , calculate if p dominates q or vice versa for (int
         * q = 0; q < solutionSet_.size(); q++) { flagDominate
         * =constraint_.compare(solutionSet.get(p),solutionSet.get(q)); if
         * (flagDominate == 0) { flagDominate
         * =dominance_.compare(solutionSet.get(p),solutionSet.get(q)); }
         *
         * if (flagDominate == -1) { iDominate[p].add(new Integer(q)); } else if
         * (flagDominate == 1) { dominateMe[p]++; } }
         *
         * // If nobody dominates p, p belongs to the first front if
         * (dominateMe[p] == 0) { front[0].add(new Integer(p));
         * solutionSet.get(p).setRank(0); } }
         */

        // -> Fast non dominated sorting algorithm
        // Contribution of Guillaume Jacquenot
        // 初始化支配我的个数的数组dominateMe[p]为0
        // 初始化我支配的个体的链表iDominate[p]
        for (int p = 0; p < solutionSet_.size(); p++) {
            // Initialize the list of individuals that i dominate and the number
            // of individuals that dominate me
            iDominate[p] = new LinkedList<Integer>();
            dominateMe[p] = 0;
        }
        // 解之间的支配关系
        for (int p = 0; p < (solutionSet_.size() - 1); p++) {
            // For all q individuals , calculate if p dominates q or vice versa
            for (int q = p + 1; q < solutionSet_.size(); q++) {
                flagDominate = constraint_.compare(solutionSet.get(p), solutionSet.get(q));
                if (flagDominate == 0) {
                    flagDominate = dominance_.compare(solutionSet.get(p), solutionSet.get(q));
                }
                // p dominate q被支配的解的个数加1
                if (flagDominate == -1) {
                    iDominate[p].add(q);
                    dominateMe[q]++;
                } else if (flagDominate == 1) {
                    iDominate[q].add(p);
                    dominateMe[p]++;
                }
            }
            // If nobody dominates p, p belongs to the first front
        }
        for (int p = 0; p < solutionSet_.size(); p++) {
            if (dominateMe[p] == 0) {
                front[0].add(p);
                solutionSet.get(p).setRank(0);
            }
        }

        // Obtain the rest of fronts
        // 对于非支配排序，在上一个循环，已经将解之间的支配关系输入到了iDominate和dominateMe列表中
        // 每一次dominateMe[p] == 0的解即表示没有解能够支配它，即它已经到达了前沿面
        // 为此我们必须遍历前一前沿的每个解，找到这些解支配的解，将其被支配个数减一
        // 找到一次就减少一次，直到为0时，即是表示这个解已经没有被支配其已经是前沿解
        int i = 0;
        Iterator<Integer> it1, it2; // Iterators
        // 当没有元素可以进行排序时，停止循环
        while (front[i].size() != 0) {
            i++;
            it1 = front[i - 1].iterator(); //遍历上一层沿面的解
            while (it1.hasNext()) {
                it2 = iDominate[it1.next()].iterator(); // it2表示上一层前沿面it1支配的所有解
                while (it2.hasNext()) {
                    int index = it2.next();
                    dominateMe[index]--; // 没找到一次就减去这个解被支配的次数一次
                    if (dominateMe[index] == 0) {
                        front[i].add(index);
                        solutionSet_.get(index).setRank(i);
                    }
                }
            }
        }
        // <-

        ranking_ = new SolutionSet[i]; // 存储的是解决方案的集合
        // 0,1,2,....,i-1 are front, then i fronts
        //  i 变量中存储的是当前总共的前沿层数
        for (int j = 0; j < i; j++) {
            ranking_[j] = new SolutionSet(front[j].size());
            it1 = front[j].iterator();
            while (it1.hasNext()) {
                ranking_[j].add(solutionSet.get(it1.next()));
            }
        }

    }

    /**
     * Constructor.
     *
     * @param solutionSet The <code>SolutionSet</code> to be ranked.
     */
    public PORanking(SolutionSet solutionSet, Solution objSet) {
        solutionSet_ = solutionSet;
        // 将isChosen 赋值给PODominanceComparator类变量 	boolean[] isChosen_
        dominance_ = new PODominanceComparator(objSet);

        // dominateMe[i] contains the number of solutions dominating i
        int[] dominateMe = new int[solutionSet_.size()];

        // iDominate[k] contains the list of solutions dominated by k
        List<Integer>[] iDominate = new List[solutionSet_.size()];

        // front[i] contains the list of individuals belonging to the front i
        List<Integer>[] front = new List[solutionSet_.size() + 1];

        // flagDominate is an auxiliar encodings.variable
        int flagDominate;

        // Initialize the fronts
        for (int i = 0; i < front.length; i++)
            front[i] = new LinkedList<Integer>();

        /*
         * //-> Fast non dominated sorting algorithm for (int p = 0; p <
         * solutionSet_.size(); p++) { // Initialice the list of individuals
         * that i dominate and the number // of individuals that dominate me
         * iDominate[p] = new LinkedList<Integer>(); dominateMe[p] = 0; // For
         * all q individuals , calculate if p dominates q or vice versa for (int
         * q = 0; q < solutionSet_.size(); q++) { flagDominate
         * =constraint_.compare(solutionSet.get(p),solutionSet.get(q)); if
         * (flagDominate == 0) { flagDominate
         * =dominance_.compare(solutionSet.get(p),solutionSet.get(q)); }
         *
         * if (flagDominate == -1) { iDominate[p].add(new Integer(q)); } else if
         * (flagDominate == 1) { dominateMe[p]++; } }
         *
         * // If nobody dominates p, p belongs to the first front if
         * (dominateMe[p] == 0) { front[0].add(new Integer(p));
         * solutionSet.get(p).setRank(0); } }
         */

        // -> Fast non dominated sorting algorithm
        // Contribution of Guillaume Jacquenot
        for (int p = 0; p < solutionSet_.size(); p++) {
            // Initialize the list of individuals that i dominate and the number
            // of individuals that dominate me
            iDominate[p] = new LinkedList<Integer>();
            dominateMe[p] = 0;
        }
        for (int p = 0; p < (solutionSet_.size() - 1); p++) {
            // For all q individuals , calculate if p dominates q or vice versa
            for (int q = p + 1; q < solutionSet_.size(); q++) {
                flagDominate = constraint_.compare(solutionSet.get(p), solutionSet.get(q));
                if (flagDominate == 0) {
                    flagDominate = dominance_.compare(solutionSet.get(p), solutionSet.get(q));
                }
                if (flagDominate == -1) {
                    iDominate[p].add(q);
                    dominateMe[q]++;
                } else if (flagDominate == 1) {
                    iDominate[q].add(p);
                    dominateMe[p]++;
                }
            }
            // If nobody dominates p, p belongs to the first front
        }
        for (int p = 0; p < solutionSet_.size(); p++) {
            if (dominateMe[p] == 0) {
                front[0].add(p);
                solutionSet.get(p).setRank(0);
            }
        }

        // Obtain the rest of fronts
        int i = 0;
        Iterator<Integer> it1, it2; // Iterators
        while (front[i].size() != 0) {
            i++;
            it1 = front[i - 1].iterator();
            while (it1.hasNext()) {
                it2 = iDominate[it1.next()].iterator();
                while (it2.hasNext()) {
                    int index = it2.next();
                    dominateMe[index]--;
                    if (dominateMe[index] == 0) {
                        front[i].add(index);
                        solutionSet_.get(index).setRank(i);
                    }
                }
            }
        }
        // <-

        ranking_ = new SolutionSet[i];
        // 0,1,2,....,i-1 are front, then i fronts
        for (int j = 0; j < i; j++) {
            ranking_[j] = new SolutionSet(front[j].size());
            it1 = front[j].iterator();
            while (it1.hasNext()) {
                ranking_[j].add(solutionSet.get(it1.next()));
            }
        }

    } // Ranking

    /**
     * Returns a <code>SolutionSet</code> containing the solutions of a given
     * rank.
     *
     * @param rank The rank
     * @return Object representing the <code>SolutionSet</code>.
     */
    public SolutionSet getSubfront(int rank) {
        return ranking_[rank];
    } // getSubFront

    /**
     * Returns the total number of subFronts founds.
     */
    public int getNumberOfSubfronts() {
        return ranking_.length;
    } // getNumberOfSubfronts
} // Ranking
