package momfo.util.vector;

public abstract class VectorGenerator {
	protected double[][] lambda_;

	public double[][] getVectors() {
		return this.lambda_;
	}


}
