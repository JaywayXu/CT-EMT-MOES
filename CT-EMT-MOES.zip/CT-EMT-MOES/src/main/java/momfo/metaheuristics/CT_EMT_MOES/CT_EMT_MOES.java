package momfo.metaheuristics.CT_EMT_MOES;

import momfo.core.*;
import momfo.qualityIndicator.QualityIndicator;
import momfo.util.Configuration;
import momfo.util.JMException;
import momfo.util.PseudoRandom;
import momfo.util.comparators.OverallConstraintViolationComparator;
import momfo.util.comparators.PODominanceComparator;
import momfo.util.wrapper.XReal;

import java.awt.*;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Comparator;



public class CT_EMT_MOES extends Algorithm {
    private int populationSize;
    private int maxEvaluations;
    private int evaluations;
    private int p;
    private double[] rmp = new double[2];

    private static Comparator dominance_;
    private static Comparator trans_dominance_;
    private SolutionSet[] resPopulation;

    SolutionSet population;
    int evalnum;

    DecimalFormat form = new DecimalFormat("#.####E0");
    int NUMTASK = problemSet_.size();
    Boolean[] Transferbyown = new Boolean[NUMTASK];
    double[] successratebyown = new double[NUMTASK];
    double[] successratebyother = new double[NUMTASK];
    int[] success_mutationbyown = new int[NUMTASK];
    int[] success_mutationbyother = new int[NUMTASK];
    int[] success_mutationbyown_con = new int[NUMTASK];
    int[] success_mutationbyown_dy = new int[NUMTASK];
    int[] success_mutationbyother_con = new int[NUMTASK];
    int[] success_mutationbyother_dy = new int[NUMTASK];
    int[] NT = new int[NUMTASK];


    public ArrayList<Integer> no_evas = new ArrayList<>();
    public ArrayList<Double> IGD1 = new ArrayList<>();
    public ArrayList<Double> IGD2 = new ArrayList<>();

    public ArrayList<Integer> L_evas_success_task1 = new ArrayList<>();
    public ArrayList<Double> L_rmptask1 = new ArrayList<>();
    public ArrayList<Double> L_total_succrate_task1 = new ArrayList<>();
    public ArrayList<Double> L_own_succrate_task1 = new ArrayList<>();
    public ArrayList<Double> L_own_succrate_con_task1 = new ArrayList<>();
    public ArrayList<Double> L_own_succrate_dy_task1 = new ArrayList<>();
    public ArrayList<Double> L_other_succrate_task1 = new ArrayList<>();
    public ArrayList<Double> L_other_succrate_con_task1 = new ArrayList<>();
    public ArrayList<Double> L_other_succrate_dy_task1 = new ArrayList<>();
    public ArrayList<Integer> L_NT_task1 = new ArrayList<>();

    public ArrayList<Integer> L_evas_success_task2 = new ArrayList<>();
    public ArrayList<Double> L_rmptask2 = new ArrayList<>();
    public ArrayList<Double> L_total_succrate_task2 = new ArrayList<>();
    public ArrayList<Double> L_own_succrate_task2 = new ArrayList<>();
    public ArrayList<Double> L_own_succrate_con_task2 = new ArrayList<>();
    public ArrayList<Double> L_own_succrate_dy_task2 = new ArrayList<>();
    public ArrayList<Double> L_other_succrate_task2 = new ArrayList<>();
    public ArrayList<Double> L_other_succrate_con_task2 = new ArrayList<>();
    public ArrayList<Double> L_other_succrate_dy_task2 = new ArrayList<>();
    public ArrayList<Integer> L_NT_task2 = new ArrayList<>();

    SolutionSet pfpoptask1;
    SolutionSet pfpoptask2;


    public CT_EMT_MOES(ProblemSet problemSet) {
        super(problemSet);
    }

    public SolutionSet execute() throws JMException, ClassNotFoundException {
        NUMTASK = problemSet_.size();

        populationSize = ((Integer) getInputParameter("populationSize")).intValue();
        maxEvaluations = ((Integer) getInputParameter("maxEvaluations")).intValue();
        p = ((Integer) getInputParameter("p")).intValue();
        rmp[0] = ((Double) getInputParameter("rmptask1")).doubleValue();
        rmp[1] = ((Double) getInputParameter("rmptask2")).doubleValue();
        evalnum = maxEvaluations / 500;

        // Initialize the variables
        population = new SolutionSet(populationSize);
        evaluations = 0;

        clearIGD();
        clearsuccessrate();
        for (int i = 0; i < populationSize / 2; i++) {
            Solution newSolution = new Solution(problemSet_);
            newSolution.setSkillFactor(0);
            population.add(newSolution);
        } // for
        for (int i = populationSize / 2; i < populationSize; i++) {
            Solution newSolution = new Solution(problemSet_);

            newSolution.setSkillFactor(1);
            population.add(newSolution);
        }

        Checkpop();
        Evalate();
        departpopulation();
        feedIGD();


        Solution[] parents = new Solution[2];
        Solution[] offSpring = new Solution[2];
        offSpring[0] = new Solution(problemSet_);
        XReal off = new XReal(offSpring[0]);
        while (evaluations < maxEvaluations) {
            for (int i = 0; i < populationSize; i++) {
                int parent_skill_factor = population.get(i).getSkillFactor();
                int num_of_var = problemSet_.get(parent_skill_factor).getNumberOfVariables();
                int start = problemSet_.get(parent_skill_factor).getStartObjPos();
                int end = problemSet_.get(parent_skill_factor).getEndObjPos();
                int M = end - start + 1;

                boolean selec[] = new boolean[problemSet_.getTotalNumberOfObjs()];
                boolean trans_selec[] = new boolean[problemSet_.getTotalNumberOfObjs()];
                setselec(selec, parent_skill_factor);
                setselec(trans_selec, (1 - parent_skill_factor));
                dominance_ = new PODominanceComparator(selec);
                trans_dominance_ = new PODominanceComparator(trans_selec);

                for (int aa = 0; aa < problemSet_.size(); aa++) {
                    success_mutationbyown[aa] = 0;
                    success_mutationbyother[aa] = 0;
                    successratebyother[aa] = 0.0;
                    successratebyown[aa] = 0.0;
                    success_mutationbyown_con[aa] = 0;
                    success_mutationbyown_dy[aa] = 0;
                    success_mutationbyother_con[aa] = 0;
                    success_mutationbyother_dy[aa] = 0;
                    NT[aa] = 0;
                }

                for (int k = 0; k < num_of_var; k++) {
                    int dimrand = PseudoRandom.randInt(0, problemSet_.get(1 - parent_skill_factor).getNumberOfVariables() - 1);
                    for (int idx = 1; idx <= 4; idx++) {
                        double rand1 = PseudoRandom.randDouble();
                        double meanoftargetdimk;
                        double meanofoppdimrand;

                        if (parent_skill_factor == 0) {
                            meanoftargetdimk = getsubpopdimmean(population, 0, populationSize / 2, k);
                            meanofoppdimrand = getsubpopdimmean(population, populationSize / 2, populationSize, dimrand);

                        } else {
                            meanoftargetdimk = getsubpopdimmean(population, populationSize / 2, populationSize, k);
                            meanofoppdimrand = getsubpopdimmean(population, 0, populationSize / 2, dimrand);
                        }
                        if (rand1 > rmp[parent_skill_factor]) {
                            Transferbyown[parent_skill_factor] = true;
                            parents[0] = population.get(i);
                            parents[1] = population.best(dominance_);
                            offSpring = SBX(parents[0], parents[1], k);
                            offSpring[0].setSkillFactor(parent_skill_factor);
                        }
                        else if (rand1 <= rmp[parent_skill_factor]) {
                            NT[parent_skill_factor] = NT[parent_skill_factor] + 1;
                            Transferbyown[parent_skill_factor] = false;
                            Solution bestfromopp;
                            double transoppdimrand;
                            int rand2;
                            if (parent_skill_factor == 0) {
                                rand2 = PseudoRandom.randInt(populationSize / 2, populationSize - 1);
                            } else {
                                rand2 = PseudoRandom.randInt(0, populationSize / 2 - 1);
                            }
                            bestfromopp = population.get(rand2);
                            transoppdimrand = bestfromopp.getDecisionVariables()[dimrand].getValue() * (meanoftargetdimk + Double.MIN_VALUE) / (meanofoppdimrand + Double.MIN_VALUE);
                            double cross = SBXtoDouble(transoppdimrand, population.get(i).getDecisionVariables()[k].getValue(), k, parent_skill_factor);
                            off.setValue(k, cross);
                        }
                        Solution tempsolution = new Solution(population.get(i));
                        tempsolution.setSkillFactor(parent_skill_factor);
                        XReal xtemp = new XReal(tempsolution);
                        double Temp;
                        Temp = OURMT(offSpring[0], idx, k);
                        if (Temp <= problemSet_.get(parent_skill_factor).getUpperLimit(k) && Temp >= problemSet_.get(parent_skill_factor).getLowerLimit(k)) {
                            xtemp.setValue(k, Temp);
                            problemSet_.get(parent_skill_factor).evaluate(tempsolution);
                            problemSet_.get(parent_skill_factor).evaluateConstraints(tempsolution);
                            evaluations++;
                            if ((evaluations % evalnum == 0) && (evaluations <= maxEvaluations)) {
                                departpopulation();
                                feedIGD();
                            }
                            int Parent_DomCount = CalDomCount(population, population.get(i), i);
                            int NewPop_DomCount = CalDomCount(population, tempsolution, i);
                            double Parent_MED = CalMED(population, population.get(i), i);
                            double NewPoP_MED = CalMED(population, tempsolution, i);
                            int offspringless = 0;
                            int parentless = 0;
                            int offspringless_or_equal = 0;
                            for (int obj_index = start; obj_index <= end; obj_index++) {
                                if (tempsolution.getObjective(obj_index) <= population.get(i).getObjective(obj_index)) {
                                    offspringless_or_equal++;
                                    if (tempsolution.getObjective(obj_index) < population.get(i).getObjective(obj_index))
                                        offspringless++;
                                } else {
                                    parentless++;
                                }
                            }
                            if ((offspringless_or_equal == M) && (offspringless > 0)) {
                                population.replace(i, tempsolution);
                                if (Transferbyown[parent_skill_factor] == true)
                                {
                                    success_mutationbyown[parent_skill_factor] = success_mutationbyown[parent_skill_factor] + 1;
                                    success_mutationbyown_con[parent_skill_factor] = success_mutationbyown_con[parent_skill_factor] + 1;
                                } else {
                                    success_mutationbyother[parent_skill_factor] = success_mutationbyother[parent_skill_factor] + 1;
                                    success_mutationbyother_con[parent_skill_factor] = success_mutationbyother_con[parent_skill_factor] + 1;
                                }
                                break;
                            }
                            else if ((offspringless) > 0 && (parentless > 0)) {
                                if (NewPop_DomCount < Parent_DomCount) {
                                    population.replace(i, tempsolution);
                                    if (Transferbyown[parent_skill_factor] == true)
                                    {
                                        success_mutationbyown[parent_skill_factor] = success_mutationbyown[parent_skill_factor] + 1;
                                        success_mutationbyown_con[parent_skill_factor] = success_mutationbyown_con[parent_skill_factor] + 1;
                                    } else {
                                        success_mutationbyother[parent_skill_factor] = success_mutationbyother[parent_skill_factor] + 1;
                                        success_mutationbyother_con[parent_skill_factor] = success_mutationbyother_con[parent_skill_factor] + 1;
                                    }//end if
                                    break;
                                }
                                else if (NewPop_DomCount == Parent_DomCount)

                                    if (NewPoP_MED > Parent_MED) {
                                        population.replace(i, tempsolution);

                                        if (Transferbyown[parent_skill_factor] == true)
                                        {
                                            success_mutationbyown[parent_skill_factor] = success_mutationbyown[parent_skill_factor] + 1;
                                            success_mutationbyown_dy[parent_skill_factor] = success_mutationbyown_dy[parent_skill_factor] + 1;
                                        } else {
                                            success_mutationbyother[parent_skill_factor] = success_mutationbyother[parent_skill_factor] + 1;
                                            success_mutationbyother_dy[parent_skill_factor] = success_mutationbyother_dy[parent_skill_factor] + 1;
                                        }//end if
                                        break;
                                    }
                            }
                        }
                    }
                }

                if (parent_skill_factor == 0) {
                    L_NT_task1.add(NT[parent_skill_factor]);
                    L_evas_success_task1.add(evaluations);
                    L_rmptask1.add(rmp[parent_skill_factor]);
                    L_total_succrate_task1.add((double) success_mutationbyown[parent_skill_factor] / problemSet_.get(parent_skill_factor).getNumberOfVariables() + (double) success_mutationbyother[0] / problemSet_.get(parent_skill_factor).getNumberOfVariables());
                    L_own_succrate_task1.add((double) success_mutationbyown[parent_skill_factor] / problemSet_.get(parent_skill_factor).getNumberOfVariables());
                    L_other_succrate_task1.add((double) success_mutationbyother[parent_skill_factor] / problemSet_.get(parent_skill_factor).getNumberOfVariables());
                    L_own_succrate_con_task1.add((double) success_mutationbyown_con[parent_skill_factor] / problemSet_.get(parent_skill_factor).getNumberOfVariables());
                    L_own_succrate_dy_task1.add((double) success_mutationbyown_dy[parent_skill_factor] / problemSet_.get(parent_skill_factor).getNumberOfVariables());
                    L_other_succrate_con_task1.add((double) success_mutationbyother_con[parent_skill_factor] / problemSet_.get(parent_skill_factor).getNumberOfVariables());
                    L_other_succrate_dy_task1.add((double) success_mutationbyother_dy[parent_skill_factor] / problemSet_.get(parent_skill_factor).getNumberOfVariables());
                } else {
                    L_NT_task2.add(NT[parent_skill_factor]);
                    L_evas_success_task2.add(evaluations);
                    L_rmptask2.add(rmp[parent_skill_factor]);
                    L_total_succrate_task2.add((double) success_mutationbyown[parent_skill_factor] / problemSet_.get(parent_skill_factor).getNumberOfVariables() + (double) success_mutationbyother[1] / problemSet_.get(parent_skill_factor).getNumberOfVariables());
                    L_own_succrate_task2.add((double) success_mutationbyown[parent_skill_factor] / problemSet_.get(parent_skill_factor).getNumberOfVariables());
                    L_other_succrate_task2.add((double) success_mutationbyother[parent_skill_factor] / problemSet_.get(parent_skill_factor).getNumberOfVariables());
                    L_own_succrate_con_task2.add((double) success_mutationbyown_con[parent_skill_factor] / problemSet_.get(parent_skill_factor).getNumberOfVariables());
                    L_own_succrate_dy_task2.add((double) success_mutationbyown_dy[parent_skill_factor] / problemSet_.get(parent_skill_factor).getNumberOfVariables());
                    L_other_succrate_con_task2.add((double) success_mutationbyother_con[parent_skill_factor] / problemSet_.get(parent_skill_factor).getNumberOfVariables());
                    L_other_succrate_dy_task2.add((double) success_mutationbyother_dy[parent_skill_factor] / problemSet_.get(parent_skill_factor).getNumberOfVariables());
                }

                if (NT[parent_skill_factor] == 0) {
                    rmp[parent_skill_factor] = rmp[parent_skill_factor] + 1.0 * (1.0 - (double) success_mutationbyown[parent_skill_factor] / problemSet_.get(parent_skill_factor).getNumberOfVariables());
                } else {
                    if (success_mutationbyother[parent_skill_factor] > success_mutationbyown[parent_skill_factor]) {
                        rmp[parent_skill_factor] = rmp[parent_skill_factor] + 1.0 * (double) success_mutationbyother[parent_skill_factor] / problemSet_.get(parent_skill_factor).getNumberOfVariables();
                        if (rmp[parent_skill_factor] > 0.5)
                            rmp[parent_skill_factor] = 0.5;
                    } else {
                        rmp[parent_skill_factor] = rmp[parent_skill_factor] - 1.0 * (1.0 - (double) success_mutationbyother[parent_skill_factor] / problemSet_.get(parent_skill_factor).getNumberOfVariables());
                        if (rmp[parent_skill_factor] < 0)
                            rmp[parent_skill_factor] = 0;
                    }
                }
            }
            departpopulation();
            boolean selectask1[] = new boolean[problemSet_.getTotalNumberOfObjs()];
            boolean selectask2[] = new boolean[problemSet_.getTotalNumberOfObjs()];
            setselec(selectask1, 0);
            setselec(selectask2, 1);
            pfpoptask1 = getParetoSol(resPopulation[0]);
            pfpoptask2 = getParetoSol(resPopulation[1]);
        }
        return population;
    } // execute

    public void setselec(boolean selec[], int taskID) {
        int start = problemSet_.get(taskID).getStartObjPos();
        int end = problemSet_.get(taskID).getEndObjPos();
        for (int i = 0; i < selec.length; i++) {
            if (i < start || i > end)
                selec[i] = false;
            else
                selec[i] = true;
        }
    }

    int CalDomCount(SolutionSet Population, Solution Individual, int indexnum) {
        int N = Population.size();
        int taskId = Individual.getSkillFactor();
        int start = problemSet_.get(taskId).getStartObjPos();
        int end = problemSet_.get(taskId).getEndObjPos();

        int DomCount = 0;
        for (int i = 0; i < N; i++) {
            if ((i == indexnum) || (Population.get(i).getSkillFactor() != taskId))
                continue;
            int Populationless = 0;
            int Populationless_or_equal = 0;
            for (int obj_index = start; obj_index <= end; obj_index++) {
                if (Population.get(i).getObjective(obj_index) * 1e20 <= Individual.getObjective(obj_index) * 1e20) {
                    Populationless_or_equal++;
                    if (Population.get(i).getObjective(obj_index) * 1e20 < Individual.getObjective(obj_index) * 1e20)
                        Populationless++;
                }
            }
            if ((Populationless_or_equal == (end - start + 1)) && (Populationless > 0))
                DomCount++;
        }
        return DomCount;
    }

    int CalDomCount(SolutionSet Population, Solution Individual) {
        int N = Population.size();
        int DomCount = 0;
        for (int i = 0; i < N; i++) {
            int Populationless = 0;
            int Populationless_or_equal = 0;
            for (int obj_index = 0; obj_index < Individual.getNumberOfObjectives(); obj_index++) {
                if (Population.get(i).getObjective(obj_index) * 1e20 <= Individual.getObjective(obj_index) * 1e20) {
                    Populationless_or_equal++;
                    if (Population.get(i).getObjective(obj_index) * 1e20 < Individual.getObjective(obj_index) * 1e20)
                        Populationless++;
                }
            }
            if ((Populationless_or_equal == Individual.getNumberOfObjectives()) && (Populationless > 0))
                DomCount++;
        }
        return DomCount;
    }

    double CalMED(SolutionSet Population, Solution Individual, int indexnum) {
        double TotalDist = 0.0;
        double NearDist = Double.MAX_VALUE;
        double MED;
        int taskId = Individual.getSkillFactor();
        int start = problemSet_.get(taskId).getStartObjPos();
        int end = problemSet_.get(taskId).getEndObjPos();
        int N = Population.size();
        int M = Population.get(0).getNumberOfObjectives();
        for (int i = 0; i < N; i++) {
            if ((i == indexnum) || (Population.get(i).getSkillFactor() != taskId))
                continue;
            double Dist = 0.0;
            for (int j = start; j <= end; j++) {
                Dist = Dist + Math.pow((Population.get(i).getObjective(j) - Individual.getObjective(j)), 2);
            }
            TotalDist = TotalDist + Math.pow(Dist, 0.5);
            if (Dist < NearDist)
                NearDist = Dist;
        }
        MED = NearDist * TotalDist;
        return MED;
    }

    public void feedIGD() {

        String pf1 = "PF/" + problemSet_.get(0).getHType() + ".pf";
        String pf2 = "PF/" + problemSet_.get(1).getHType() + ".pf";
        QualityIndicator indicator1 = new QualityIndicator(problemSet_.get(0), pf1);
        QualityIndicator indicator2 = new QualityIndicator(problemSet_.get(1), pf2);

        double igd1 = indicator1.getIGD(resPopulation[0]);
        double igd2 = indicator2.getIGD(resPopulation[1]);
        no_evas.add(evaluations);
        IGD1.add(igd1);
        IGD2.add(igd2);
    }

    public void clearIGD() {
        no_evas.clear();
        IGD1.clear();
        IGD2.clear();
    }

    public void clearsuccessrate() {
        L_evas_success_task1.clear();
        L_rmptask1.clear();
        L_total_succrate_task1.clear();
        L_own_succrate_task1.clear();
        L_own_succrate_con_task1.clear();
        L_own_succrate_dy_task1.clear();
        L_other_succrate_task1.clear();
        L_other_succrate_con_task1.clear();
        L_other_succrate_dy_task1.clear();
        L_NT_task1.clear();
        L_evas_success_task2.clear();
        L_rmptask2.clear();
        L_total_succrate_task2.clear();
        L_own_succrate_task2.clear();
        L_own_succrate_con_task2.clear();
        L_own_succrate_dy_task2.clear();
        L_other_succrate_task2.clear();
        L_other_succrate_con_task2.clear();
        L_other_succrate_dy_task2.clear();
        L_NT_task2.clear();
    }


    public void departpopulation() {
        resPopulation = new SolutionSet[problemSet_.size()];
        for (int i = 0; i < problemSet_.size(); i++)
            resPopulation[i] = new SolutionSet();
        for (int i = 0; i < population.size(); i++) {
            Solution sol = population.get(i);

            int pid = sol.getSkillFactor();
            int start = problemSet_.get(pid).getStartObjPos();
            int end = problemSet_.get(pid).getEndObjPos();

            Solution newSolution = new Solution(end - start + 1);
            newSolution.setSkillFactor(pid);
            for (int k = start; k <= end; k++) {
                newSolution.setObjective(k - start, sol.getObjective(k));
                newSolution.setDecisionVariables(sol.getDecisionVariables());

            }

            resPopulation[pid].add(newSolution);
        }
    }

    public double getsubpopdimmean(SolutionSet pop, int j, int k, int dim) throws JMException {
        double dimmean;
        double sum = 0;
        for (int i = j; i < k; i++) {
            sum = pop.get(i).getDecisionVariables()[dim].getValue() + sum;
        }
        dimmean = sum / (k - j);
        return dimmean;
    }


    public void Checkpop() throws JMException {
        XReal popvar;
        for (int i = 0; i < population.size(); i++) {
            popvar = new XReal(population.get(i));
            for (int j = 0; j < problemSet_.get(population.get(i).getSkillFactor()).getNumberOfVariables(); j++) {
                double var = population.get(i).getDecisionVariables()[j].getValue();
                double low = problemSet_.get(population.get(i).getSkillFactor()).getLowerLimit(j);
                double up = problemSet_.get(population.get(i).getSkillFactor()).getUpperLimit(j);
                if (var > up || var < low)
                    var = PseudoRandom.randDouble(low, up);
                popvar.setValue(j, var);
            }
        }
    }

    public void Evalate() throws JMException {
        for (int i = 0; i < populationSize; i++) {
            problemSet_.get(population.get(i).getSkillFactor()).evaluate(population.get(i));
            problemSet_.get(population.get(i).getSkillFactor()).evaluateConstraints(population.get(i));
            evaluations++;
        }
    }

    public double OURMT(Solution solution, int idx, int k) throws JMException {

        double Temp;
        double random_precise = Math.pow(10, PseudoRandom.randInt(0, p - 1));
        double deltax = 1.0 / random_precise * PseudoRandom.randInt(1, 9);

        if (idx == 1) {
            Temp = solution.getDecisionVariables()[k].getValue() * deltax;

        } else if (idx == 2) {
            Temp = solution.getDecisionVariables()[k].getValue() / deltax;

        } else if (idx == 3) {
            Temp = solution.getDecisionVariables()[k].getValue() + deltax;

        } else {
            Temp = solution.getDecisionVariables()[k].getValue() - deltax;
        }
        return Temp;
    }


    public double SBXtoDouble(double parent1, double parent2, int k, int skillfactor) throws JMException {
        double rand = PseudoRandom.randDouble();
        double c1;
        double c2;
        double beta;
        double eta = 20.0;

        if (rand < 0.5) {
            beta = Math.pow(rand * 2, 1.0 / (1.0 + eta));
        } else beta = Math.pow(1.0 / (2 - rand * 2), 1.0 / (1 + eta));
        c1 = 0.5 * ((1 + beta) * parent1 + (1 - beta) * parent2);
        c2 = 0.5 * ((1 - beta) * parent1 + (1 + beta) * parent2);

        if (c2 > problemSet_.get(skillfactor).getUpperLimit(k))
            c2 = problemSet_.get(skillfactor).getUpperLimit(k);
        else if (c2 < problemSet_.get(skillfactor).getLowerLimit(k))
            c2 = problemSet_.get(skillfactor).getLowerLimit(k);
        return c2;
    }

    public Solution[] SBX(Solution parent1, Solution parent2, int index) throws JMException {
        double rand = PseudoRandom.randDouble();
        Solution[] offSprings = new Solution[2];
        offSprings[0] = new Solution(parent1);
        offSprings[1] = new Solution(parent2);
        double c1;
        double c2;
        XReal X_offSpring1 = new XReal(offSprings[0]);
        XReal X_offSpring2 = new XReal(offSprings[1]);
        double beta;
        double eta = 20.0;

        if (rand < 0.5) {
            beta = Math.pow(rand * 2, 1.0 / (1.0 + eta));
        } else beta = Math.pow(1.0 / (2 - rand * 2), 1.0 / (1 + eta));
        c1 = 0.5 * ((1 + beta) * X_offSpring1.getValue(index) + (1 - beta) * X_offSpring2.getValue(index));
        c2 = 0.5 * ((1 - beta) * X_offSpring1.getValue(index) + (1 + beta) * X_offSpring2.getValue(index));

        if (c2 > problemSet_.get(offSprings[0].getSkillFactor()).getUpperLimit(index))
            c2 = problemSet_.get(offSprings[0].getSkillFactor()).getUpperLimit(index);
        else if (c2 < problemSet_.get(offSprings[0].getSkillFactor()).getLowerLimit(index))
            c2 = problemSet_.get(offSprings[0].getSkillFactor()).getLowerLimit(index);
        X_offSpring1.setValue(index, c2);
        X_offSpring2.setValue(index, c1);
        return offSprings;
    }


    public SolutionSet getParetoSol(SolutionSet pop) {
        SolutionSet paretosolSet = new SolutionSet();

        int N = pop.size();
        for (int i = 0; i < N; i++) {
            int caldom = CalDomCount(pop, pop.get(i));
            if (caldom == 0)
            {
                paretosolSet.add(pop.get(i));
            }
        }
        return paretosolSet;
    }

}
