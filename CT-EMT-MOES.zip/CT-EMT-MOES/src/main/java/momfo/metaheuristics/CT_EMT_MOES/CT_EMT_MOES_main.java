package momfo.metaheuristics.CT_EMT_MOES;

import momfo.core.*;
import momfo.qualityIndicator.QualityIndicator;
import momfo.util.JMException;

import java.io.*;
import java.lang.reflect.InvocationTargetException;
import java.text.DecimalFormat;
import java.util.ArrayList;

public class CT_EMT_MOES_main {
    public static int POPULATIONSIZE__ = 200;
    public static int MAXEVALUATIONS__ = 200 * 1000;
    public static int P__ = 3;
    public static double[] RMP__ = {0.5, 0.5};


    public static int TIMES__ = 3;

    //loop test mode
    public static void main(String args[]) throws IOException, JMException, ClassNotFoundException, NoSuchMethodException, InvocationTargetException, IllegalAccessException {

        ProblemSet problemSet;
        Algorithm algorithm;
        int taskNumber = 2;

        int problemStart = 1;
        int problemEnd =9;
        System.out.println("Algo: CT-EMT-MOES");

        for (int pCase = problemStart; pCase <= problemEnd; pCase++) {
            problemSet = (ProblemSet) Class
                    .forName("momfo.problems.benchmarks.ClassicalMOMTO" + pCase)
                    .getMethod("getProblem")
                    .invoke(null, null);


            double pro1_max = problemSet.get(0).getUpperLimit(5);
            double pro1_min = problemSet.get(0).getLowerLimit(5);
            double pro2_max = problemSet.get(1).getUpperLimit(5);
            double pro2_min = problemSet.get(1).getLowerLimit(5);
            double pro_max = Math.max(pro1_max, pro2_max);
            double pro_min = Math.min(pro1_min, pro2_min);


            problemSet.setUnifiedLowerLimit(pro_min);
            problemSet.setUnifiedUpperLimit(pro_max);

            String pf1 = "PF/" + problemSet.get(0).getHType() + ".pf";
            String pf2 = "PF/" + problemSet.get(1).getHType() + ".pf";
            algorithm = new CT_EMT_MOES(problemSet);
            Cal_sta cal = new Cal_sta();

            algorithm.setInputParameter("populationSize", POPULATIONSIZE__);
            algorithm.setInputParameter("maxEvaluations", MAXEVALUATIONS__);
            algorithm.setInputParameter("p", P__);
            algorithm.setInputParameter("rmptask1", RMP__[0]);
            algorithm.setInputParameter("rmptask2", RMP__[1]);


            String name1 = problemSet.get(0).getName();
            String name2 = problemSet.get(1).getName();
            DecimalFormat form = new DecimalFormat("#.###E0");

            System.out.println("RunID\t" + "IGD for " + name1 + "\t" + "IGD for " + name2);
            int times = TIMES__;
            double[][] iterIGD = new double[taskNumber][times];
            double[][] iterHV = new double[taskNumber][times];
            double[][] iterEpsilon = new double[taskNumber][times];

            ArrayList<Integer>[] Time_no_evas = new ArrayList[times];
            ArrayList<Double>[] Time_IGD1 = new ArrayList[times];
            ArrayList<Double>[] Time_IGD2 = new ArrayList[times];
            for (int i = 0; i < times; i++) {
                ArrayList<Integer> a = new ArrayList<>();
                ArrayList<Double> b = new ArrayList<>();
                ArrayList<Double> c = new ArrayList<>();
                Time_no_evas[i] = a;
                Time_IGD1[i] = b;
                Time_IGD2[i] = c;
            }
            for (int t = 1; t <= times; t++) {
                SolutionSet population = algorithm.execute();
                Time_no_evas[t - 1] = (ArrayList<Integer>) ((CT_EMT_MOES) algorithm).no_evas.clone();
                Time_IGD1[t - 1] = (ArrayList<Double>) ((CT_EMT_MOES) algorithm).IGD1.clone();
                Time_IGD2[t - 1] = (ArrayList<Double>) ((CT_EMT_MOES) algorithm).IGD2.clone();

                SolutionSet[] resPopulation = new SolutionSet[problemSet.size()];
                for (int i = 0; i < problemSet.size(); i++)
                    resPopulation[i] = new SolutionSet();
                for (int i = 0; i < population.size(); i++) {
                    Solution sol = population.get(i);

                    int pid = sol.getSkillFactor();
                    int start = problemSet.get(pid).getStartObjPos();
                    int end = problemSet.get(pid).getEndObjPos();
                    Solution newSolution = new Solution(end - start + 1);

                    for (int k = start; k <= end; k++)
                        newSolution.setObjective(k - start, sol.getObjective(k));
                    resPopulation[pid].add(newSolution);
                }

                QualityIndicator indicator1 = new QualityIndicator(problemSet.get(0), pf1);
                QualityIndicator indicator2 = new QualityIndicator(problemSet.get(1), pf2);

                double igd1 = indicator1.getIGD(resPopulation[0]);
                double igd2 = indicator2.getIGD(resPopulation[1]);
                double hv1 = indicator1.getHypervolume(resPopulation[0]);
                double hv2 = indicator2.getHypervolume(resPopulation[1]);
                double epsilon1 = indicator1.getEpsilon(resPopulation[0]);
                double epsilon2 = indicator2.getEpsilon(resPopulation[1]);
                iterIGD[0][t - 1] = igd1;
                iterIGD[1][t - 1] = igd2;//
                iterHV[0][t - 1] = hv1;
                iterHV[1][t - 1] = hv2;
                iterEpsilon[0][t - 1] = epsilon1;
                iterEpsilon[1][t - 1] = epsilon2;//
                System.out.println(t + "\t" + "IGD" + form.format(igd1) + "\t" + form.format(igd2));
                System.out.println(t + "\t" + "hv" + form.format(hv1) + "\t" + form.format(hv2));
                System.out.println(t + "\t" + "Epsilon" + form.format(epsilon1) + "\t" + form.format(epsilon2));
            }
            for (int i = 0; i < taskNumber; i++) {
                System.out.println("Task" + i);
                System.out.println("平均值IGD  " + form.format(cal.Mean(iterIGD[i])));
                System.out.println("平均值HV  " + form.format(cal.Mean(iterHV[i])));
                System.out.println("平均值Epsilon  " + form.format(cal.Mean(iterEpsilon[i])));
            }
        }
    }
}

