package momfo.problems.base;

import momfo.core.Problem;
import momfo.core.Solution;
import momfo.core.Variable;
import momfo.util.JMException;

public class MMDTLZ extends Problem {
    String gType_;
    Integer alpha_;

    public MMDTLZ(int numberOfObjectives, int numberOfVariables, int alpha, double lg, double ug) {
        numberOfObjectives_ = numberOfObjectives; //表示该任务的目标函数个数
        numberOfVariables_ = numberOfVariables; // 变量数，在文档中显示为50

        gType_ = "sphere";//g函数?

        alpha_ = alpha;

        int num = numberOfVariables_ - numberOfObjectives_ + 1;

        // System.out.println(num);

        shiftValues_ = new double[num];
        rotationMatrix_ = new double[num][num];

        upperLimit_ = new double[numberOfVariables_];
        lowerLimit_ = new double[numberOfVariables_];

        for (int var = 0; var < numberOfObjectives_ - 1; var++) {
            lowerLimit_[var] = 0.0;
            upperLimit_[var] = 1.0;
        } // for

        for (int var = numberOfObjectives_ - 1; var < numberOfVariables; var++) {
            lowerLimit_[var] = lg;
            upperLimit_[var] = ug;
        }//lowerLimit数组中前面存储的是目标函数值的最大值和最小值，后面存储的是变量值的最大值和最小值

        for (int i = 0; i < num; i++)
            shiftValues_[i] = 0;

        for (int i = 0; i < num; i++) {
            for (int j = 0; j < num; j++) {
                if (i != j)
                    rotationMatrix_[i][j] = 0;
                else
                    rotationMatrix_[i][j] = 1;
            }
        }

        if (numberOfObjectives == 2)
            hType_ = "circle";
        else
            hType_ = "sphere";
    }

    public MMDTLZ(int numberOfObjectives, int numberOfVariables, int alpha, double lg, double ug, String gType,
                  double[] shiftValues, double[][] rotationMatrix) {
        numberOfObjectives_ = numberOfObjectives;
        numberOfVariables_ = numberOfVariables;

        alpha_ = alpha;
        gType_ = gType;
        shiftValues_ = shiftValues;
        rotationMatrix_ = rotationMatrix;

        upperLimit_ = new double[numberOfVariables_];
        lowerLimit_ = new double[numberOfVariables_];

        for (int var = 0; var < numberOfObjectives_ - 1; var++) {
            lowerLimit_[var] = 0.0;
            upperLimit_[var] = 1.0;
        } // for

        for (int var = numberOfObjectives_ - 1; var < numberOfVariables; var++) {
            lowerLimit_[var] = lg;
            upperLimit_[var] = ug;
        }
        if (numberOfObjectives == 2)
            hType_ = "circle";
        else
            hType_ = "sphere";
    }

    public void evaluate(Solution solution) throws JMException {
//        double vars[] = scaleVariables(solution);// 获取solutions中的决策变量并将其缩放到需要解决的问题范围
        double vars[]=new double[numberOfVariables_];
        Variable[] decisionVariables = solution.getDecisionVariables();
        for (int i = 0; i < numberOfVariables_; i++) {
            //两个上下界限之间到底有什么区别和联系
            vars[i] = decisionVariables[i].getValue();
        }
        double[] xI = new double[numberOfObjectives_ - 1];
        //对于PIMS1和2来说numberOfObjectives_为2 2-1=1
        double[] xII = new double[numberOfVariables_ - numberOfObjectives_ + 1];
        // 对于PIMS 50-2+1=49
        for (int i = 0; i < numberOfObjectives_ - 1; i++)//PIMS双目标问题，i=0,即取第一个x，即x[0]变量
            xI[i] = vars[i];

        for (int i = numberOfObjectives_ - 1; i < numberOfVariables_; i++)//PIMS双目标问题i从1开始，即是从第二个x开始，一直遍历到x的末尾
            xII[i - numberOfObjectives_ + 1] = vars[i];
        xII = transformVariables(xII);// 对xII中的决策变量进行偏移和旋转的处理

        double[] f = new double[numberOfObjectives_];//注意是一个多目标问题，所以应该函数结果设置为数组结构

        double g = evalG(xII);

        for (int i = 0; i < numberOfObjectives_; i++)
            f[i] = 1 + g;

        solution.setGFunValue(1 + g);

        for (int i = 0; i < numberOfObjectives_; i++) { //遍历多目标问题中的函数
            for (int j = 0; j < numberOfObjectives_ - (i + 1); j++)
                f[i] *= Math.cos(Math.pow(xI[j], alpha_) * 0.5 * Math.PI);
            if (i != 0) {
                int aux = numberOfObjectives_ - (i + 1);
                f[i] *= Math.sin(Math.pow(xI[aux], alpha_) * 0.5 * Math.PI);
            } // if
        } // for

        for (int i = 0; i < numberOfObjectives_; i++)
            solution.setObjective(startObjPos_ + i, f[i]);
    }

    double evalG(double[] xII) throws JMException {
        if (gType_.equalsIgnoreCase("sphere"))
            return GFunctions.getSphere(xII);
        else if (gType_.equalsIgnoreCase("rosenbrock"))
            return GFunctions.getRosenbrock(xII);
        else if (gType_.equalsIgnoreCase("ackley"))
            return GFunctions.getAckley(xII);
        else if (gType_.equalsIgnoreCase("griewank"))
            return GFunctions.getGriewank(xII);
        else if (gType_.equalsIgnoreCase("rastrigin"))
            return GFunctions.getRastrigin(xII);
        else if (gType_.equalsIgnoreCase("mean"))
            return GFunctions.getMean(xII);
        else {
            System.out.println("Error: g function type " + gType_ + " invalid");
            return Double.NaN;
        }
    }

    public void setGType(String gType) {
        gType_ = gType;
    }

    public String getHType() {
        return hType_;
    }

}
